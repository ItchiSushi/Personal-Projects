package za.ac.cput.pengu_tv;

import android.content.Intent;

public interface RecyclerViewInterface  {

    void onItemClick(int pos);
}
